let out = document.querySelector('.out');
let select = document.querySelector('.select');
let searchInp = document.querySelector('.search');

let city = 'London,uk';
select.innerHTML = selectItem();
getWeather();

function getWeather() {
  fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=ec8c823c6d48a8074d5d7c09ed5be3b5`)
    .then(function (resp) {return resp.json() })
    .then(function (data) {
      console.log(data);
      out.innerHTML = showWeather(data);
      
  }) 

  .catch(function () {
    out.innerHTML = 'This city not found';
      city = 'London';
      getWeather();
  });
}

function selectItem() {
  return `
    <option value="London,uk">London,uk</option>
    <option value="New York">New York</option>
    <option value="Kiev">Kiev</option>
    <option value="Washington">Washington</option>
    <option value="Cape Town">Cape Town</option>
    <option value="Venice">Venice</option>
  `
}

function showWeather(item) {
  return `
    <div class="test">
      <div class="out__wrap">
        <div class="card">
            <div class="card__heading card__mb">
              <div class="card__city">${item.name}</div>
            </div>
            <div class="card__heading">
              <p class="card__сlouds">${item.weather[0]['description']}</p>
              <img class="card__img-icon" src="https://openweathermap.org/img/wn/${item.weather[0]['icon']}@2x.png">
            </div>
            <div class="card__heading">
              <p class="card__сlouds">Temperature</p>
              <p class="card__degrees">${Math.round(item.main.temp - 273) + '&deg'}</p>
            </div>
            <div class="card__heading">
              <p class="card__сlouds">Day</p>
              <p class="card__degrees">${Math.round(item.main.temp_max - 273) + '&deg'}</p>
            </div>
            <div class="card__heading">
              <p class="card__сlouds">Night</p>
              <p class="card__degrees">${Math.round(item.main.temp_min - 273) + '&deg'}</p>
            </div>
            <div class="card__heading">
              <p class="card__text">Humidity</p>
              <p class="card__degrees">${item.main.humidity + '%'}</p>
            </div> 
            <div class="card__heading">
              <p class="card__text">Pressure</p>
              <p class="card__сlouds">${item.main.pressure}</p>
            </div> 
            <div class="card__heading">
              <p class="card__text">Wind Direction</p>
              <p class="card__сlouds">${item.wind.deg}</p>
            </div>
            <div class="card__heading">
              <p class="card__text">Wind Speed</p>
              <p class="card__сlouds">${item.wind.speed}</p>
            </div>
        </div>
      </div>
    </div>
  `
}

function f1() {
  city = select.value;
  getWeather()
}
select.onchange = f1;

searchInp.addEventListener('keydown', (e) => {
  if(e.key === 'Enter') {
      let value = searchInp.value;
      if(!value) return false;
      city = value;
      getWeather();
      searchInp.value = ''
  }
})





 





  

  

 


  
